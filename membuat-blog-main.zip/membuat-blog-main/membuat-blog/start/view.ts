import edge from 'edge.js'
import string from '@adonisjs/core/helpers/string'

edge.global('pluralize', string.pluralize)
